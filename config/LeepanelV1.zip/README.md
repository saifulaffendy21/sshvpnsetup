OcsPanels
=========
Simple and lightweight panel for Reseller SSH based on Webmin API, 100% free.


Copyright & License
-------
Copyright (c) 2016
[GNU Public License]
